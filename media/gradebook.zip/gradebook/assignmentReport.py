# usage: python assignmentReport.py 134
# opens CSV file of grades for MUSI 134
# finds all unique assignment names in records
# lists assignment names and prompts for single assignment name
# locates all records for that assignment
# for each grade category in asst, lists records by student name and score
# also gives median score for each category, number passing (3 or 4 / 4)
# and total number of records

import csv
import sys
import os
from numpy import *

course = sys.argv[1]
courseFile = 'musi' + course + '-grades.csv'

grades = csv.reader(open(courseFile, 'rb'), delimiter=',')
gradesList = []
gradesList.extend(grades)
gradeCategories = []

def findAssignmentTypes(classAssignmentList):
	assignmentTypes = []
	lineNumber = 1

	for row in classAssignmentList:
		if lineNumber != 1:
#			print lineNumber
			assignmentTypes.append(row[2])
		else:
			lineNumber = lineNumber + 1
	assignmentSet = sorted(set(assignmentTypes))
	return assignmentSet

def findEvalCategories(classAssignmentList):
#	r = 0
#	for row in classAssignmentList:
#		while r == 0:
#			gradeCategories = row
#			r = r + 1
	gradeCategories = classAssignmentList.pop(0)
	gradeCategories.remove('Student')
	gradeCategories.remove('First name')
	gradeCategories.remove('Assignment')
	return gradeCategories
	
def findAssignmentEvalCategories(classAssignmentList, assignment, evalCategories):
	activeCategories = []
	for category in evalCategories:
		index = evalCategories.index(category)
		for row in classAssignmentList:
			if row[0] != 'Student':
				if row[2] == assignment:
					if row[index+3] != '':
						activeCategories.append(category)
	activeCategories = sorted(set(activeCategories))
	return activeCategories


assignments = findAssignmentTypes(gradesList)
evalCategories = findEvalCategories(gradesList)
totalCategories = len(evalCategories)


os.system('clear')
print 'MUSI', course, 'Grade Report'
print ' '
print 'Assignments:'

for assignment in assignments:
	print assignment
print ' '

assignmentQuery = raw_input('Enter assignment for report : ')
gradeCategories = findAssignmentEvalCategories(gradesList, assignmentQuery, evalCategories)

for category in gradeCategories:
	print ' '
	print '-', category, '-'
	print ' '
	index = evalCategories.index(category)
	valueList = []
	for row in gradesList:
		value = row[index+3]
		student = row[0]
		assignment = row[2]
		if assignment == assignmentQuery:
			if value != '':
				print (student + ':'), value
				valueList.append(int(value))
	totalPassing = 0
	for value in valueList:
		if value >= 3:
			totalPassing = totalPassing + 1
	print ' '
	valueArray = array(valueList)
	medianValue = median(valueArray)
	print 'Median:', medianValue
	print 'Total passing:', totalPassing
	print 'Total evaluations:', len(valueList)
	print ' '
