# usage: python studentReport.py 134 Smith
# opens grade file for MUSI 134 
# finds all grade categories for MUSI 134 from first line of CSV file
# finds all records for student named Smith
# for each grade category, lists Smith's assignments by name and score

import csv
import sys
import os

course = sys.argv[1]
courseFile = 'musi' + course + '-grades.csv'
if len(sys.argv) < 3:
	student = raw_input('Student name: ')
else:
	student = sys.argv[2]

grades = csv.reader(open(courseFile, 'rb'), delimiter=',')
gradesList = []
gradesList.extend(grades)
gradeCategories = []

# find number of columns to get number of grade categories
# take first row of headings to get grade category names

r = 0
for row in gradesList:
	while r == 0:
		gradeCategories = row
		r = r + 1
gradeCategories.remove('Student')
gradeCategories.remove('First name')
gradeCategories.remove('Assignment')
totalCategories = len(gradeCategories)

os.system('clear')
print student
print " "

for category in gradeCategories:
	print category, '---------------'
	print ' '
	index = gradeCategories.index(category)
	for row in gradesList:
		if row[0] == student:
			if row[index+3] != '':
				print (row[2] + ':'), row[index+3]
	print ' '
	print ' '
