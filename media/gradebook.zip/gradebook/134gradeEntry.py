# usage: python 134gradeEntry.py
# opens pre-made CSV file for MUSI 134, which contains a header row of
# grade categories
# prompts for assignment name
# prompts for grade categories covered in assignment by list (y/n)
# prompts for student name
# prompts for score 0-4 for each grade category covered
# adds line to CSV file with student name and grades
# repeats until student name "0" is entered

import csv
import sys
import os

openFile = open('musi134-grades.csv', 'ab')
appendGrade = csv.writer(openFile, delimiter=',')

class Assignment():

	def __init__(self):
		self.data = []
	
	asstName = ''
	studentLast = ''
	studentFirst = ''
	voiceLeadingKB = ''
	voiceLeadingPopRock = ''
	functionalBass = ''
	harmonicSyntax = ''
	formalFunctions = ''
	cadences = ''
	phraseThemeID = ''
	hermeneutics = ''
	formIDPopRock = ''
	harmonyPopRock = ''
	writing = ''
	software = ''
	
evalTypes = [ 'Voice-leading (keyboard style)', 'Voice-leading (pop/rock)', \
'Functional bass', 'Harmonic syntax', 'Formal functions', 'Cadences', \
'Phrase/theme ID', 'Hermeneutics', 'Form ID (pop/rock)', \
'Harmony (pop/rock)', 'Writing', 'Software' ]

varName = { 'Voice-leading (keyboard style)':'voiceLeadingKB', \
'Voice-leading (pop/rock)':'voiceLeadingPopRock', \
'Functional bass':'functionalBass', \
'Harmonic syntax':'harmonicSyntax', \
'Formal functions':'formalFunctions', \
'Cadences': 'cadences', \
'Phrase/theme ID':'phraseThemeID', \
'Hermeneutics':'hermeneutics', \
'Form ID (pop/rock)':'formIDPopRock', \
'Harmony (pop/rock)':'harmonyPopRock', \
'Writing':'writing', \
'Software':'software' \
}

evalTypeInclusion = {}
score = {}
	
os.system('clear')
print 'Music Theory II (MUSI 134) Grade Entry'
print ' '

assignmentTitle = raw_input('Assignment title: ')

print ' '
print 'Enter evaluation categories.'
print ' '

for type in evalTypes:
	score[type] = ''
	if raw_input((type + ': y/n [default is y] ')) == 'n':
		evalTypeInclusion[type] = 0
	else:
		evalTypeInclusion[type] = 1

print ' '
loop = 1

while loop == 1:
	student = raw_input('Student last name: [0 to finish] ')
	print ' '
	if student == '0':
		loop = 0
	else:
		assignmentEval = Assignment()
		assignmentEvalRow = []
		assignmentEvalRow.append(student)
		assignmentEvalRow.append('')
		assignmentEvalRow.append(assignmentTitle)
		for type in evalTypes:
			name = varName[type]
			if evalTypeInclusion[type] == 1:
				value = input((type + ': [0-4] '))
				if 0 <= value <= 4:
					assignmentEval.name = value
				else:
					assignmentEval.name = 'ERROR'
			else:
				assignmentEval.name = ''
			assignmentEvalRow.append(assignmentEval.name)

		appendGrade.writerow(assignmentEvalRow)
		print ' '
		
openFile.close()