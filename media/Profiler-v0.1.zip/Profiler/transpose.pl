#!/usr/bin/perl

#  This file is part of Profiler.
#  Copyright 2010 Kris P. Shaffer
#  http://kris.shaffermusic.com

#  Profiler is free software: you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation, version 3.

#  Profiler is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.

#  You should have received a copy of the GNU General Public License
#  along with Profiler.  If not, see <http://www.gnu.org/licenses/>.

use File::Basename qw/ /;

my %chordProb;

foreach $movement (@ARGV) {
	open SOURCE, "<$movement" or die "Could not open $movement: $!";

# import profile into hash
	while (<SOURCE>) {
		chomp($chordProb{(split /,/)[0]} = (split /,/)[1]);
	}

# print probability hash to screen to check
#	foreach $pitchClass (0..11) {
#		print "$pitchClass,$chordProb{$pitchClass}\n";
#	}

	foreach $interval (0..11) {
# create filename for profile
		my $tallyFile = File::Basename::basename $movement;
		$tallyFile =~ s/(\.csv$|\.txt$)//i;
		$tallyFile = $tallyFile . "-$interval.csv";
	
# open source and destination files
		open DESTINATION, ">./ChordDistributionProfiles/$tallyFile" or die "Could not create $tallyFile: $!";
	
# transpose profile and write to file
		my %transposition;
		foreach (0..11) {
			$transposition{$_} = $chordProb{(($_ - $interval) % 12)};
			print DESTINATION "$_,$transposition{$_}\n";
			}
	
	print "process complete for $tallyFile.\n";
	close DESTINATION;
	}
	
	close SOURCE;
}