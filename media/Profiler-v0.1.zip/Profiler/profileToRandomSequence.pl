#!/usr/bin/perl

#  This file is part of Profiler.
#  Copyright 2010 Kris P. Shaffer
#  http://kris.shaffermusic.com

#  Profiler is free software: you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation, version 3.

#  Profiler is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.

#  You should have received a copy of the GNU General Public License
#  along with Profiler.  If not, see <http://www.gnu.org/licenses/>.

use File::Basename qw/ /;

my %chordProb;

foreach $movement (@ARGV) {

# create filename for profile
	my $tallyFile = File::Basename::basename $movement;
	$tallyFile =~ s/(\-profile.csv$|\-profile.txt$)//i;
	$tallyFile = $tallyFile . "-random.csv";
	
# open source and destination files
	open SOURCE, "<$movement" or die "Could not open $movement: $!";
	open DESTINATION, ">./ChordSequences/$tallyFile" or die "Could not create $tallyFile: $!";

# import profile into hash
	while (<SOURCE>) {
		chomp($chordProb{(split /,/)[0]} = (split /,/)[1]);
	}

# print probability hash to screen to check
#	foreach $pitchClass (0..11) {
#		print "$pitchClass,$chordProb{$pitchClass}\n";
#	}
	
# convert probabilities to max points for probability ranges
	my %randomTest;
		$randomTest{-1} = 0;
	foreach (0..11) {
		$randomTest{$_} = ($randomTest{($_-1)} + $chordProb{$_});
		}

# write random sequence of 10,000 chords to file based on probability
	foreach (1..10000) {
		$randomValue = rand($randomTest{11});
		print DESTINATION
			$randomValue < $randomTest{0} 	? "0\n" :
			$randomValue < $randomTest{1}  	? "1\n" :
			$randomValue < $randomTest{2}  	? "2\n" :
			$randomValue < $randomTest{3}  	? "3\n" :
			$randomValue < $randomTest{4}  	? "4\n" :
			$randomValue < $randomTest{5}  	? "5\n" :
			$randomValue < $randomTest{6}  	? "6\n" :
			$randomValue < $randomTest{7}  	? "7\n" :
			$randomValue < $randomTest{8}  	? "8\n" :
			$randomValue < $randomTest{9} 	? "9\n" :
			$randomValue < $randomTest{10} 	? "10\n" :
			$randomValue < $randomTest{11} 	? "11\n" :
				"error";
	}
	
	print "process complete for $tallyFile.\n";
	
	close SOURCE;
	close DESTINATION;
}