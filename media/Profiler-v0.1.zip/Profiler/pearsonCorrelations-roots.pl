#!/usr/bin/perl

#  This file is part of Profiler.
#  Copyright 2010 Kris P. Shaffer
#  http://kris.shaffermusic.com

#  Profiler is free software: you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation, version 3.

#  Profiler is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.

#  You should have received a copy of the GNU General Public License
#  along with Profiler.  If not, see <http://www.gnu.org/licenses/>.

use Statistics::Basic qw(:all nofill);
use File::Basename qw/ /;


my @REPERTOIRE = @ARGV;
# my @REPERTOIRE = glob "./ChordDistributionProfiles/*";
my %profile;
my $fileCount = @REPERTOIRE;

open DESTINATION, ">./Results/chordDistributionPearsonCorrelations.csv" or die "Could not create chordDistributionPearsonCorrelations.csv: $!";

foreach $movement (@REPERTOIRE) {
	
# open source and destination files
	open SOURCE, "<$movement" or die "Could not open $movement: $!";

# import profile into hash
	while (<SOURCE>) {
		chomp($chordProb{(split /,/)[0]} = (split /,/)[1]);
	}
	$profile{$movement} = vector( $chordProb{0}, $chordProb{1}, $chordProb{2}, $chordProb{3}, $chordProb{4}, $chordProb{5}, $chordProb{6}, $chordProb{7}, $chordProb{8}, $chordProb{9}, $chordProb{10}, $chordProb{11} )
}

# print header row of profile names
print DESTINATION ",";
my $ticker = 1;
foreach $movement (@REPERTOIRE) {
	my $header = File::Basename::basename $movement;
	$header =~ s/(\-profile.csv$|\-profile.txt$)//i;
	print DESTINATION "$header";
	if ($ticker < $fileCount) { print DESTINATION ","; }
	$ticker++;
}
print DESTINATION "\n";

# calculate and return Pearson correlation coefficients
foreach $movement (@REPERTOIRE) {
	$row = $movement;
	my $rowName = File::Basename::basename $movement;
	$rowName =~ s/(\-profile.csv$|\-profile.txt$)//i;
	print DESTINATION "$rowName,";
	my $ticker = 1;
	
	foreach $movement (@REPERTOIRE) {
		$column = $movement;
		$coefficient = correlation ($profile{$row},$profile{$column});
		printf DESTINATION "%5.4f", $coefficient;
		if ($ticker < $fileCount) { print DESTINATION ","; }
		$ticker++;
		}
	
	print DESTINATION "\n";
}
		
close SOURCE;
close DESTINATION;