#!/usr/bin/perl

#  This file is part of Profiler.
#  Copyright 2010 Kris P. Shaffer
#  http://kris.shaffermusic.com

#  Profiler is free software: you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation, version 3.

#  Profiler is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.

#  You should have received a copy of the GNU General Public License
#  along with Profiler.  If not, see <http://www.gnu.org/licenses/>.

use File::Basename qw/ /;
my %progCount;

foreach $movement (@ARGV) {

# create filename for profile
	my $tallyFile = File::Basename::basename $movement;
	$tallyFile =~ s/(\-progressions.csv$|\-progressions.txt$)//i;
	$progSeqFile = $tallyFile . "-progressions.csv";
	$progProfileFile = $tallyFile . "-progressionProfile.csv";
	
# open source and destination files
	open PROFILE, ">./ChordProgressionProfiles/$progProfileFile" or die "Could not create $progProfileFile: $!";
	open PROGRESSIONS, "<./ChordProgressionSequences/$progSeqFile" or die "Could not open $progSeqFile: $!";

# set profile & probability values for each root to zero
	foreach (0..11) {
		$progCount{$_} = 0;
		}
	my $totalChords = 0;

# count chord roots
	while (<PROGRESSIONS>) {
		$_ =~ s/\n/,x\n/; # accommodate roots only or roots-comma-something
		my $localProg = (split /,/)[0];
		$progCount{$localProg}++;
		$totalChords++;
	}

# convert raw tally to probability (sum 1)
	my %chordProb;
	foreach (0..11) {
		$chordProb{$_} = ($progCount{$_} / $totalChords);
		}

# write chord-root probability to destination file
	foreach $intClass (0..11) {
		print PROFILE "$intClass,$chordProb{$intClass}\n";
	}

	print "process complete for $progProfileFile.\n";
	
	close PROGRESSIONS;
	close PROFILE;
}