#!/usr/bin/perl

#  This file is part of Profiler.
#  Copyright 2010 Kris P. Shaffer
#  http://kris.shaffermusic.com

#  Profiler is free software: you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation, version 3.

#  Profiler is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.

#  You should have received a copy of the GNU General Public License
#  along with Profiler.  If not, see <http://www.gnu.org/licenses/>.

use File::Basename qw/ /;
my %progCount;

# create directories for progressions and profiles
	mkdir "ChordProgressionSequences", 0755 or warn "Could not create directory for chord progression sequences: $!";
	mkdir "ChordProgressionProfiles", 0755 or warn "Could not create directory for chord progression profiles: $!";

foreach $movement (@ARGV) {

# create filename for profile
	my $tallyFile = File::Basename::basename $movement;
	$tallyFile =~ s/(\.csv$|\.txt$)//i;
	$progSeqFile = $tallyFile . "-progressions.csv";
	$progProfileFile = $tallyFile . "-progressionProfile.csv";
	
# open source and destination files
	open CHORDS, "<$movement" or die "Could not open $movement: $!";
	open SEQUENCE, ">./ChordProgressionSequences/$progSeqFile" or die "Could not create $progSeqFile: $!";

# read chord sequence into array
	my @roots;
	my $chordCount = 0;
	my $tertianCount = 0;
	while (<CHORDS>) {
		$_ =~ s/\n/,x\n/; # accommodate roots only or roots-comma-something
		$roots[$chordCount] = (split /,/)[0];
		$chordCount++;
		unless ($localRoot =~ /q|x/) { $tertianCount++; }
	}

# convert chord sequence to progression sequence and write to file
	foreach $chord (0..($chordCount - 1)) {
		$rootInterval = ((($roots[$chord+1] - $roots[$chord]) * 7) % 12);
		unless ($roots[$chord] =~ /q|x/ || $roots[$chord+1] =~ /q|x/) { 
			print SEQUENCE "$rootInterval\n";
		}
	}
	
	print "chord sequence written to $progSeqFile.\n";
	close CHORDS;
	close SEQUENCE;
}