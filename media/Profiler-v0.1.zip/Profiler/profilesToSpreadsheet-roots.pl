#!/usr/bin/perl

#  This file is part of Profiler.
#  Copyright 2010 Kris P. Shaffer
#  http://kris.shaffermusic.com

#  Profiler is free software: you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation, version 3.

#  Profiler is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.

#  You should have received a copy of the GNU General Public License
#  along with Profiler.  If not, see <http://www.gnu.org/licenses/>.

use File::Basename qw/ /;

my %chordProb;

open DESTINATION, ">./Results/chordDistributionProfiles.csv" or die "Could not create chordDistributionProfiles.csv: $!";

# print header
print DESTINATION "movement,0,1,2,3,4,5,6,7,8,9,10,11\n";

foreach $movement (@ARGV) {

# open source and destination files
	open SOURCE, "<$movement" or die "Could not open $movement: $!";

# import profile into hash
	while (<SOURCE>) {
		chomp($chordProb{(split /,/)[0]} = (split /,/)[1]);
	}

# write profile to output csv file
	my $fileName = File::Basename::basename $movement;
	print DESTINATION "$fileName";
	foreach (0..11) {
		print DESTINATION ",$chordProb{$_}";
	}
	print DESTINATION "\n";
	
	print "process complete for $movement.\n";
	
	close SOURCE;
}

	close DESTINATION;