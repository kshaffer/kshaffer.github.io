#!/usr/bin/perl

#  This file is part of Profiler.
#  Copyright 2010 Kris P. Shaffer
#  http://kris.shaffermusic.com

#  Profiler is free software: you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation, version 3.

#  Profiler is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.

#  You should have received a copy of the GNU General Public License
#  along with Profiler.  If not, see <http://www.gnu.org/licenses/>.

use File::Basename qw/ /;

`./pearsonCorrelations-roots.pl ChordDistributionProfiles/*`;
`./pearsonCorrelations-progressions.pl ChordProgressionProfiles/*`;
`./spearmanCorrelations-roots.pl ChordDistributionProfiles/*`;
`./spearmanCorrelations-progressions.pl ChordProgressionProfiles/*`;