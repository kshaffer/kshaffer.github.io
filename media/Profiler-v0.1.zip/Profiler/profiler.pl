#!/usr/bin/perl

#  This file is part of Profiler.
#  Copyright 2010 Kris P. Shaffer
#  http://kris.shaffermusic.com

#  Profiler is free software: you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation, version 3.

#  Profiler is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.

#  You should have received a copy of the GNU General Public License
#  along with Profiler.  If not, see <http://www.gnu.org/licenses/>.

use File::Basename qw/ /;

my @ARGVPROGS;
my @ARGVCHORDPROFS;
my @ARGVPROGPROFS;

foreach $chordFile (@ARGV) {
	my $baseFile = File::Basename::basename $chordFile;
	$baseFile =~ s/(\.csv$|\.txt$)//i;
	my $progSeqFile = "ChordProgressionSequences/" . $baseFile . "-progressions.csv";
	my $chordProfileFile = "ChordDistributionProfiles/" . $baseFile . "-profile.csv";
	my $progProfileFile = "ChordProgressionProfiles/" . $baseFile . "-progressionProfile.csv";
	push @ARGVPROGS, $progSeqFile;
	push @ARGVCHORDPROFS, $chordProfileFile;
	push @ARGVPROGPROFS, $progProfileFile;
	}

`./chordsToProfile.pl @ARGV`;
`./chordsToProgs.pl @ARGV`;
`./progsToProfile.pl @ARGVPROGS`;
`./profilesToSpreadsheet-roots.pl @ARGVCHORDPROFS`;
`./profilesToSpreadsheet-progressions.pl @ARGVPROGPROFS`;