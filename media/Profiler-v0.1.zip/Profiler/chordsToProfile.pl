#!/usr/bin/perl

#  This file is part of Profiler.
#  Copyright 2010 Kris P. Shaffer
#  http://kris.shaffermusic.com

#  Profiler is free software: you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation, version 3.

#  Profiler is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.

#  You should have received a copy of the GNU General Public License
#  along with Profiler.  If not, see <http://www.gnu.org/licenses/>.

use File::Basename qw/ /;
my %chordProfile;

# create directory for profiles
	mkdir "ChordDistributionProfiles", 0755 or warn "Could not create directory for chord distribution profiles: $!";

foreach $movement (@ARGV) {

# create filename for profile
	my $tallyFile = File::Basename::basename $movement;
	$tallyFile =~ s/(\.csv$|\.txt$)//i;
	$tallyFile = $tallyFile . "-profile.csv";
	
# open source and destination files
	open SOURCE, "<$movement" or die "Could not open $movement: $!";
	open DESTINATION, ">./ChordDistributionProfiles/$tallyFile" or die "Could not create $tallyFile: $!";

# set profile & probability values for each root to zero
	foreach (0..11) {
		$chordProfile{$_} = 0;
		}
	$totalchords = 0;

# count chord roots
	while (<SOURCE>) {
		$_ =~ s/\n/,x\n/; # accommodate roots only or roots-comma-something
		my $localRoot = (split /,/)[0];
		$chordProfile{$localRoot}++;
		unless ($localRoot =~ /q|x/) { 
			$totalChords++;
		}
	}

# convert raw tally to probability (sum 1)
	my %chordProb;
	foreach (0..11) {
		$chordProb{$_} = ($chordProfile{$_} / $totalChords);
		}

# write chord-root probability to destination file
	foreach $pitchClass (0..11) {
		print DESTINATION "$pitchClass,$chordProb{$pitchClass}\n";
	}

	print "process complete for $tallyFile.\n";
	
	close SOURCE;
	close DESTINATION;
}